package sample;

import sample.model.Produto;

public class MainProduto  {
    public static void main(String[] args) {
        Produto produto1 = new Produto();
        produto1.setNome("mamão papaia");
        produto1.setPreco(8);
        System.out.println(produto1);

        Produto produto2= new Produto();
        produto2.setNome("ameixa seca ");
        produto2.setPreco(7.5);
        System.out.println(produto2);

        Produto produto3= new Produto();
        produto3.setNome("abacaxi tailandes");
        produto3.setPreco(30);
        System.out.println(produto3);


        double total = produto1.getPreco()+produto2.getPreco()+produto3.getPreco();
        System.out.println("total da feira: "+total);
    }


}
