package br.com.sistema.service;
import br.com.sistema.model.Funcionario;
import java.util.List;
//camada de serviço em ingles
//usamos p criar as assinaturas dos metodos

public interface FuncionarioService {
    //metodos de consulta
    public Funcionario findById (Long id);
    public List <Funcionario> findAll();

    //save e delete
    public boolean save(Funcionario funcionario);

    public boolean delete(Long id);

}
