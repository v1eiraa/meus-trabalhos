package sample.model;

public class PeopleFisica extends People {

    private String cpf;
    private String rg;


    public PeopleFisica(String nome, String cpf, String rg) {
        super(nome);
        this.cpf = cpf;
        this.rg = rg;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }


    public String toString() {
        return super.toString() +"\n CPF :  " + cpf + "\n RG: " + rg;
    }
}