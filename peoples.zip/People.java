package sample.model;

public abstract class People {

    private String nome;
    private  Endereco endereco;


    public People(String nome){ this.nome=nome; }


    public String getNome(){return nome;}
    public void setNome(String nome){this.nome=nome;}


    public Endereco getEndereco(){return endereco;}
    public  void setEndereco (String rua,int numero, String bairro,String cpf) {

        Endereco endereco = new Endereco();
        endereco.setRua(rua);
        endereco.setNumero(numero);
        endereco.setBairro(bairro);
        this.endereco= endereco;
    }
    public String toString() {
        return "\n Nome: " +
                this.nome + "\n   " + this.endereco;
    }

}


