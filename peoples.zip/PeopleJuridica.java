package sample.model;

public class PeopleJuridica extends People {

    private String cnpj;
    private String ie;


    public PeopleJuridica(String nome, String cnpj, String ie) {
        super(nome);
        this.cnpj = cnpj;
        this.ie = ie;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getIe() {
        return ie;
    }

    public void setIe(String ie) {
        this.ie = ie;
    }


    public String toString() {
        return super.toString() + "\n CNPJ :  " + cnpj + "\n IE: " + ie;
    }
}