package sample.model;

public class Ingrediente {

    private String nome;
    private String qtde;
    private String unidadeMedida;

    public void setNome(String nome) { this.nome = nome; }

    public String getNome() { return this.nome; }

    public void setQtde(String qtde) { this.qtde = qtde; }

    public String getQtde() { return this.qtde; }

    public void setUnidadeMedida(String unidadeMedida) { this.unidadeMedida = unidadeMedida; }

    public String getUnidadeMedida() { return this.unidadeMedida; }

    public String toString(){
        return " Ingredientes: " + nome + " Quantidade: " + qtde + " \n\n Medidas: " + unidadeMedida;

    }


}