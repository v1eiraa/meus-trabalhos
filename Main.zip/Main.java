package sample;


import sample.model.Cliente;

public class Main {


    public static void main(String[] args)
            {
    /* Conta conta = new Conta( "12345-67", "987");
        System.out.println(conta.extrato());
        conta.depositar(1000.60);

     Conta conta2 = new Conta("345-78", "543");
     System.out.println(conta2.extrato());
     conta2.depositar(5000);
     System.out.println(conta2.extrato());
     */

       /*  Carro carro = new Carro(699,"33E88");
        System.out.println("velocidade do fusca : "+ carro.acelerar(200));
        System.out.println("placa do fusca: " + carro.consultarPlaca());
        carro.freiar(20);

        Carro carro2= new Carro  (200,"00E489");
        System.out.println("velocidade da ferrari : "+ carro2.acelerar(250));
        System.out.println("placa da ferrari: "+ carro2.consultarPlaca());
        carro2.freiar(100); */


        /*class Main {
            public static void main(String args[]) {

                double nota1 = 10;
                double nota2 = 1;
                double media = (nota1 + nota2) / 2;
                System.out.println("Média: " + media);

                if (media >= 6) {
                    System.out.println("aprovado");
                    System.out.println("Reprovado");
                } else {
                    System.out.println("exame");
                    double nota3 = 10;
                    double nota4 = 10;
                    double exame = (nota3 + nota4) / 2;
                    System.out.println("Média final : " + exame);
                }
            }
        }*/

      /*  Cliente cliente= new Cliente("vitor" );
        cliente.setEmail("vitor@email.com");
        cliente.setTelefone("1123-5555");
        cliente.setIdade(191);
        System.out.println(cliente); */

    }


}



