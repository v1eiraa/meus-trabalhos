package sample;

import sample.model.Receita;
import sample.model.Ingrediente;

public class MainReceitaeIgredientes  {

    public static void main(String[] args) {

        Receita receita = new Receita();
        receita.setNome("bolo de abacaxi ");
        receita.setDescricao("Bata no liquidificador os ovos, açúcar, margarina e depois adicione a farinha aos poucos.\n" +
                "Por último o fermento, bata bem até ficar uma massa lisa sem bolinhas.\n" +
                "Na fôrma de bolo coloque o açúcar direto na fôrma e derreta até virar um caramelo.\n" +
                "Espere esfriar, coloque o abacaxi que cortou e acrescente toda a massa e coloque para assar.\n" +
                "No forno a 200°C asse por 50 minutos. \n ");


        System.out.println(receita);



        Ingrediente ingredientes = new Ingrediente();
        ingredientes.setNome("xícaras de açúcar, \n" +  "ovos inteiros , \n "+ "colheres de (sopa) de margarina, \n" + "xícaras de farinha de trigo, \n" + "leite ou 1 copo pequeno, \n " + " fermento para bolo \n ");
        ingredientes.setUnidadeMedida("2 xícaras de açúcar\n" +
                "3 ovos inteiros\n" +
                "2 colheres de (sopa) de margarina\n" +
                "1 e 1/2 xícaras de farinha de trigo\n" +
                "200 ml de leite ou 1 copo pequeno\n" +
                "1 colher (sopa) de fermento para bolo");

        System.out.println(ingredientes);




    }
}