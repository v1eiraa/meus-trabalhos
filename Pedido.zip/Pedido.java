package sample.model;

import java.util.List;

public class Pedido {
    private String descricao;
    private  Double data;
    private  Double total;
    private List<ItensDoPedido>  itensDoPedido;


    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) {this.descricao= descricao;}


    public Double getData() { return data; }
    public void setData(Double data) {this.data= data;}

    public Double getTotal() { return total; }
    public void setTotal(Double total) {this.total= total;}

    public List<ItensDoPedido> getItensDoPedido() { return itensDoPedido; }
    public void setItensDoPedido(List<ItensDoPedido> itensDoPedido)
    { this.itensDoPedido = itensDoPedido; }

    public String toString() {
        return "Descrição do pedido : " + descricao+ ", " + ", Data : " + data
                + ", " + ", Total do pedido : "+ total + ", " +", Itens do Pedido "+
                " , " + itensDoPedido;
    }


   // public void getDescrição() {
    }

   // public void setDescrição(String s) {
    //}
//}
