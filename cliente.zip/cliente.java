package sample.cliente.model ;

public class cliente {
}
