package sample;
import sample.model.People;
import sample.model.PeopleFisica;
import sample.model.PeopleJuridica;

public class MainPeople {
        public static void main(String[] args) {

            PeopleFisica peopleFisica = new PeopleFisica("Vitor","128473-22","432423443");
            peopleFisica.setEndereco("do jura",260,"ingleses","Floripa");
            System.out.println(peopleFisica);

            PeopleJuridica peopleJuridica= new PeopleJuridica("moises","88271330","3828374");
            peopleJuridica.setEndereco("praça XV",128,"centro","Floripa");
            System.out.println(peopleJuridica);

        }



}
