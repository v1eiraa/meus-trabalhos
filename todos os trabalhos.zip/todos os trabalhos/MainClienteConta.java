package sample;

import sample.model.Cliente;
import sample.model.Conta;


public class MainClienteConta {

    public static void main(String[] args) {

   Cliente cliente = new Cliente();
   cliente.setNome("vitor o brabo");
   cliente.setIdade(17);
   cliente.setTelefone("9994851");
   cliente.setEmail("vitoropika@gmail.com");


        Conta conta = new Conta("Banco do Brasil", "No Limited");
        conta.depositar(1000000);
        cliente.setConta(conta);
       System.out.println(cliente.toString());

    }












}