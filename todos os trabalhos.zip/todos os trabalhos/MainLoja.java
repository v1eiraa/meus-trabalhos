package sample.model;

public class MainLoja {

    public static void main(String[] args) {
        Produto produto = new Produto();
        produto.setNome("Mouse");
        System.out.println("Pedido: " + produto.getNome());
        produto.setPreco(49.99);
        System.out.println("Preço: " + "R$" + produto.getPreco());

        Pedido pedido = new Pedido();
        pedido.setData(10.0);
        System.out.println("Data: " + pedido.getData());
        pedido.setTotal(50.00);
        System.out.println("Total: " + "R$" + pedido.getTotal());
        pedido.setDescricao("Mouse com fio USB Logitech M110 com Clique Silencioso - Preto.\n");
        System.out.println("Descrição: " + pedido.getDescricao());

        Produto2 produto2 = new Produto2();
        produto2.setNomeii("Mouse Pad");
        System.out.println("Pedido: " + produto2.getNomeii());
        produto.setPreco(9.99);
        System.out.println("Preço: " + "R$" + produto.getPreco());

        Pedido  pedido2 = new Pedido();
        pedido.setData(10.0);
        System.out.println("Data: " + pedido.getData());
        pedido.setTotal(10.00);
        System.out.println("Total: " + "R$" + pedido.getTotal());
        pedido.setDescricao("Mouse Pad Tecido Emborrachado Reflex, Multicor.");
        System.out.println("Descrição: " + pedido.getDescricao());

    }

}