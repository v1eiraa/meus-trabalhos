package sample;
import sample.model.Funcionario;
import sample.model.Clientefc;
import sample.model.Pessoafc;

public class MainAgencia {
    public static void main(String[] args) {
        Funcionario funcionario= new Funcionario("Davy","Policial Rodoviario Federal","10.000R$");
        funcionario.setSobrenome("Vieira");
        funcionario.setEmail("Davyvieira@gmail.com");
        funcionario.setTelefone("48984135153");
        System.out.println(funcionario);

        Funcionario funcionario2= new Funcionario("Benjamin","Agente Federal","U$11.000");
        funcionario2.setSobrenome("Vieira");
        funcionario2.setEmail("Benjaminvieiraa@gmail.com");
        funcionario2.setTelefone("489758029");
        System.out.println(funcionario2);


    }



}

