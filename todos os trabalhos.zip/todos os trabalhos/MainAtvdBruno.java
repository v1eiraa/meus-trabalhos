package sample.model;

public class MainAtvdBruno {


    public static void main(String[] args) {
      /*  int n1 = 10, n2 = 10;
        int n3 = produto(n1, n2);
        System.out.println("Produto: " + n3);

    }

    public static int produto(int a, int b) {
        int c = a * b;
        return c;
    }
    */
       /* int[] num1 = new int[5];
        num1[0] = 10;
        num1[1] = 20;
        num1[2] = 30;
        num1[3] = 40;
        num1[4] = 50;

        for (int i = 0; i < 5; i++)
            System.out.print(num1[i] + " ");

        int[] num2 = {10, 20, 30, 40, 50};
        for (int i = 0; i < 5; i++)
            System.out.print(num2[i] + " ");

        System.out.print("\n");
        int[] num3 = new int[5];
        for (int i = 0; i < 5; i++) {
            num3[i] = num1[i] + num2[i];
            System.out.print(num3[i] + " ");
        }
    } */

      /*  int n1 = 100, n2 = 2;
        int n3 = Divisao(n1, n2);
        System.out.println("Divisao : " + n3);

    }

    public static int Divisao(int a, int b) {
        int c = a / b;
        return c;
    } */

        p1(); p2();p3();
    }
    public static void p1() {
        for (int i = 1; i <= 100; i++)
            System.out.print(i + " ");
        System.out.println("\n");
    }

    public static void p2() {
        for (int i = 101; i <= 200; i++)
            System.out.print(i + " ");
        System.out.println("\n");
    }
    public static void p3() {
        for (int i = 201; i <= 300; i++)
            System.out.print(i + " ");

    }

}





