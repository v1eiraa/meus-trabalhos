package sample;

import sample.model.Carroo;
import sample.model.Caminhao;
import sample.model.Veiculo;

public class  MainVeiculos {
    public static void main(String[] args) {

        Carroo carro = new Carroo(" nissan", 4);
        carro.setMarca("volvo "," Carro  potente");
        System.out.println(carro);

        Caminhao caminhao = new Caminhao(" caminhao matador", 42);
        caminhao.setMarca("nike", " caminhao do hype");
        System.out.println(caminhao);
    }
}
