package sample;

import sample.model.ItensDoPedido;
import sample.model.Produto;
import sample.model.Pedido;



public class MainProdutos {
    public static void main(String[] args) {

        Produto produto= new Produto();
        produto.setNome("boné");
        produto.setPreco(10);

        Produto produto2= new Produto();
        produto2.setNome("camiseta");
        produto2.setPreco(10);






    }



}



