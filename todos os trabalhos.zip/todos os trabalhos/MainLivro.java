package sample;

import sample.model.Livro;

    public class MainLivro {
        public static void main(String[] args) {


       /* Produto produto1 = new Produto();
        produto1.setNome("mamão papaia");
        produto1.setPreco(8);
        System.out.println(produto1);
//muda os nome
        Produto produto2= new Produto();
        produto2.setNome("ameixa seca ");
        produto2.setPreco(7.5);
        System.out.println(produto2);
//muda os nome
        Produto produto3= new Produto();
        produto3.setNome("abacaxi tailandes");
        produto3.setPreco(30);
        System.out.println(produto3);


        double total = produto1.getPreco()+produto2.getPreco()+produto3.getPreco();
        System.out.println("total da feira: "+total);
    }
    */
            Livro livro = new Livro("livro da xuxa");
            System.out.println("livro : "+livro.getTitulo());


            livro.setAutor("xuxa");
            System.out.println("autor : "+livro.getAutor());

            livro.setEditora("xuxas editors");
            System.out.println("Editora "+livro.getEditora());

            livro.setAno(1950);
            System.out.println("ano : "+livro.getAno());


        }
    }
