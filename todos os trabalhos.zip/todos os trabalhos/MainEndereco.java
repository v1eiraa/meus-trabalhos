/*package sample;


import sample.model.Endereco;
import sample.model.Livro;

public class MainEndereco {


    public static void main(String[] args)

    {
        Endereco endereco = new Endereco ();


        endereco.setRua("pousada rancho vieira  ");
        System.out.println("Rua : "+ endereco.getRua());


        endereco.setNumero(27);
        System.out.println("Numero  : "+endereco.getNumero());

        endereco.setBairro("tijucas ");
        System.out.println("Bairro : "+endereco.getBairro());

        endereco.setCidade("biguaçu");
        System.out.println("Cidade : "+endereco.getCidade());



    }


}
*/