package sample;
import sample.model.Calculos;

public class MainCalcular {
    //
    public static void main(String[] args) {
        Calculos calculos = new Calculos();
        calculos.soma(10.4, 2.75);
        System.out.println("soma: " + calculos);

        Calculos calculos2 = new Calculos();
        calculos2.subtrair(10, 2, 1);
        System.out.println("subtrair: "+ calculos2);

        Calculos calculos3 = new Calculos();
        calculos2.multiplicar(1, 10, 4);
        System.out.println("multiplicar: " + calculos3);


        Calculos calculos4 = new Calculos();
        calculos2.multiplicar(1, 2, 100);
        System.out.println("Dividir: " + calculos4);

    }
}