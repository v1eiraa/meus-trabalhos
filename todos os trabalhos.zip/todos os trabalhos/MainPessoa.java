package sample;

import sample.model.Pessoa;

import java.security.spec.RSAOtherPrimeInfo;

public class MainPessoa {

    public static void main(String[] args)

    {
        Pessoa pessoa = new Pessoa();

        pessoa.setNome("cabeça de alho");
        System.out.println("Nome : "+pessoa.getNome());
        pessoa.setDataNascimento("27/01/2004");
        System.out.println("Data de Nascimento : "+ pessoa.getDataNascimento());

        System.out.println("\n\n");

        Pessoa pessoa2 = new Pessoa();

        pessoa2.setNome("paolo batinelas");
        System.out.println("Nome : "+pessoa2.getNome());
        pessoa2.setDataNascimento("30/02/1700");
        System.out.println("Data de Nascimento : "+ pessoa2.getDataNascimento());

    }


}


