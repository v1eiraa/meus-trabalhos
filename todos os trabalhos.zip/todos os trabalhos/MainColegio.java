package sample;

import jdk.swing.interop.SwingInterOpUtils;
import sample.model.Teacher;
import sample.model.Humano;
import sample.model.Aluno;


public class MainColegio {
    public static void main(String[] args) {

        Aluno aluno = new Aluno("Davy", 8, 10);
        System.out.println(aluno);

       Teacher teacher= new Teacher("rico",10,150);
        System.out.println(teacher);
    }
}